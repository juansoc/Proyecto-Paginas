<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css"> 
	<title>Consultar Proyectos</title>
</head>


<?php


	$conexion = mysql_connect('localhost','root');

	mysql_select_db("proyecto_paginas",$conexion);


	$query = "SELECT P.Nombre, P.Lugar, P.Fecha, T.Nombre_Area, U.Nombre FROM proyecto P
				INNER JOIN tipo_proyecto T ON P.Tipo_Proyecto_Id = T.Id 
				INNER JOIN usuario U ON P.Usuario_Id = U.Id;";
   	$dato = mysql_query($query);
	
	

?>

 <label> <?php echo "Usuario Conectado: ".$_SESSION['UsuarioC'];?> </label>

<body background="Imagenes/fondo1.jpg">
	<div class="container-fluid">		
		<div class="row">


		<br><br><br><br><br>

		<div class="col-lg-1"></div>  
      		<div class="col-lg-3">
        		<ul class="nav nav-pills nav-stacked" role="navegation" >
        		<li ><a href="proyecto.php" title="CrearProyecto">Crear Proyectos</a></li>
        		<li class="active"><a href="Consultar.php" class="navbar-link" title ="ConsultarProyecto">Consultar Proyectos</a></li>
        		<li ><a href="Imagen.php">Cargar Imagenes</a></li>
        		</ul>
        </div>


      <br>

		

<div class="col-lg-6"></div>
<div class="col-lg-6" id="Estilo1">

<label><h2>Proyectos Creados</h2></label>

<table border="3">
    <thead >
      <th class="success">Nombre</th>
      <th class="success">Lugar</th>
      <th class="success">Fecha</th>
      <th class="success">Area</th>
      <th class="success">Usuario</th>
    </thead>
		<?php
	    while ($record=mysql_fetch_row($dato)) { 
		?>	   
	<tr>                                 
	  <td><?php  echo " ".$record[0];?> </td>  
	  <td><?php  echo " ".$record[1];?> </td>
	  <td><?php  echo " ".$record[2];?> </td>
	  <td><?php  echo " ".$record[3];?> </td>		
	  <td><?php  echo " ".$record[4];?> </td>
	</tr>	
		<?php
		}
		?>
</table>

</div>



</div>
</div>

		
</body>
</html>