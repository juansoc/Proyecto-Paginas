<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css"> 
	<title>Clientes</title>
</head>


<?php


	$conexion = mysql_connect('mysql4.000webhost.com','a7340928_iconico','iconico4');
	mysql_select_db("a7340928_iconico",$conexion);


	$query = "select * from proyecto";
	$dato = mysql_query($query);
	
?>

<body>
	
	    <table border="3" class="table table-striped">
          <thead >
	       <th class="success">id</th>
	       <th class="success">Nombre</th>
			</thead>

<?php
	while ($record=mysql_fetch_row($dato)) { 
?>	   
<tr>                                 
	
	<td> <a href="verimagenes2.php?var1=<?php  echo $record[0];?>"><?php  echo " ".$record[0];?></a></td>  
	<td><?php  echo " ".$record[1];?> </td>
</tr>
	
<?php
	}

?>