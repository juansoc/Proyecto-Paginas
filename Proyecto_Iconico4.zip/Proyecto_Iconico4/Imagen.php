<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/estilos.css"> 
	<title>CargarImagen</title>
</head>

<?php


  $conexion = mysql_connect('localhost','root');
  mysql_select_db("proyecto_paginas",$conexion);


  $query = "SELECT * FROM proyecto";
  
  $datop = mysql_query($query);
?>


<label> <?php echo "Usuario Conectado: ".$_SESSION['UsuarioC'];?> </label>



<script type="text/javascript">
  function valido()
    {
      if (document.form1.Nombre.value=="" || document.form1.Ruta_Almacenamiento.value=="" || document.form1.Descripcion.value=="") {
        alert('Faltan datos por Ingresar');
        return false;
      };
    }
</script>


<body background="Imagenes/fondo1.jpg">


<div lass="container-fluid">
<div class="row">
<br><br><br><br><br>

<div class="col-lg-1"></div>  
    <div class="col-lg-3">
    	<ul class="nav nav-pills nav-stacked" role="navegation" >
      		<li ><a href="proyecto.php" title="CrearProyecto">Crear Proyectos</a></li>
       		<li ><a href="Consultar.php" class="navbar-link" title ="ConsultarProyecto">Consultar Proyectos</a></li>
       		<li class="active"><a href="Imagen.php">Cargar Imagenes</a></li>
    	</ul>
    </div>



<div class="col-md-6" style="border: 1px solid rgb(0, 0, 0);" id="Estilo1"> 
<div class="col-md-12" align="center"><h2>Cargar Imagenes</h2></div>


 	<div class="col-md-2"></div>
	<div class="col-md-6">
	<br/>

	<form id="form1" name="form1" method="post" action="InsertarImagen.php" enctype="multipart/form-data" onsubmit="return valido()">

		<label>Nombre:</label>
		<br/>
		<input id="iProyecto" type="text" name="Nombre"/>
		<br/>


		<label>Elige una imagen:</label>
		<br/>
		<input type="file" name="Ruta_Almacenamiento"/>
		<br/>
		<label>Descripcion</label>
		<br/>
		<textarea id="iProyecto" cols="50" rows="5" name="Descripcion"></textarea>
		<br/>

        <br/>        
        <label style="text-align:left;">Proyecto</label>
               
        <select name="iProyecto" id="iProyecto">
        <?php
          while ($record=mysql_fetch_row($datop)) { 
        ?>                               
        <option value="<?php  echo " ".$record[0];?>"><?php  echo " ".$record[1];?></option>   
        <?php
        }
        ?>
		
		<input id="iProyecto" type="submit" value="Guardar Imagen"/>


		</select>		
	</form>


	</div>
	</div>


</div>
</div>

</body>
</html>