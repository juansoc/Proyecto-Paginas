<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css"> 
	<title>CargarImagen</title>
</head>

<?php


  $conexion = mysql_connect('localhost','root');
  mysql_select_db("proyecto_paginas",$conexion);


  $query = "SELECT * FROM proyecto";
  
  $datop = mysql_query($query);
?>


<label> <?php echo "Usuario Conectado: ".$_SESSION['UsuarioC'];?> </label>

<body>


<div lass="container-fluid">
<div class="row">
<br><br><br><br><br>

<div class="col-lg-1"></div>  
    <div class="col-lg-3">
    	<ul class="nav nav-pills nav-stacked" role="navegation" >
      		<li ><a href="proyecto.php" title="CrearProyecto">Crear Proyectos</a></li>
       		<li ><a href="Consultar.php" class="navbar-link" title ="ConsultarProyecto">Consultar Proyectos</a></li>
       		<li class="active"><a href="Imagen.php">Cargar Imagenes</a></li>
    	</ul>
    </div>



<div class="col-md-6" style="border: 1px solid rgb(0, 0, 0);"> 
<div class="col-md-12" style="border: 1px solid rgb(255, 255, 255);" align="center"><h2>Cargar Imagenes</h2></div>


 	<div class="col-md-2"></div>
	<div class="col-md-6">
	<br/>

	<form method="post" action="InsertarImagen.php" enctype="multipart/form-data">

		<label>Nombre:</label>
		<br/>
		<input type="text" name="Nombre"/>
		<br/>


		<label>Elige una imagen:</label>
		<br/>
		<input type="file" name="Ruta_Almacenamiento"/>
		<br/>
		<label>Descripcion</label>
		<br/>
		<textarea cols="50" rows="5" name="Descripcion"></textarea>
		<br/>

        <br/>        
        <label style="text-align:left;">Proyecto</label>
               
        <select name="iProyecto">
        <?php
          while ($record=mysql_fetch_row($datop)) { 
        ?>     
                               
        <option value="<?php  echo " ".$record[0];?>"><?php  echo " ".$record[1];?></option>
    
   
        <?php
        }
        ?>
		<br><br><br><br/>
		<input type="submit" value="Enviar"/>


		</select>		
	</form>


	</div>
	</div>


</div>
</div>

</body>
</html>