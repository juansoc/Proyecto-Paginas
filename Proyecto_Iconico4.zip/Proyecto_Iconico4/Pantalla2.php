<?php 
session_start();
?>


<!DOCTYPE html>
<html lang="es">

<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css"> 

    <title>Pantalla2</title>
</head>
<?php

 

  $conexion = mysql_connect('localhost','root');

  mysql_select_db("bdexamen",$conexion);


  $query = "SELECT U.usuario, U.nombre, U.apellido, U.direccion, T.tipo FROM usuarios U
        INNER JOIN tipousuario T ON U.tipousuario_id = T.Id 
        ORDER BY U.Id";
  

  $Usuario = mysql_query($query); 
  
?>

<body>
  <div class="container-fluid">   
    <div class="row">
    <a href="PantallaAcceso.php" class="btn btn-default btn-lg " role="button">Salir</a>
     

    <br><br><br><br><br>

    <div class="col-md-3"><br><br><br><br><br><br><br><br><br><br></div>
     
     <div class="col-md-4"></div>
     <label> <?php echo "Usuario Conectado: ".$_SESSION['UsuarioC'];
              ?> </label> 
        
      
        <br><br>
        <div class="col-md-5" style="text-align:left;" > 
            
    <table border="3" class="table table-striped">
          <thead >
          <th class="success">Usuario</th>
          <th class="success">Nombre</th>
          <th class="success">Apellido</th>
          <th class="success">Direccion</th>
          <th class="success">Tipo Usuario</th>

          </thead>
  
<?php
  while ($record=mysql_fetch_row($Usuario)) { 
?>     
<tr>                                 
  <td><?php  echo " ".$record[0];?> </td>  
  <td><?php  echo " ".$record[1];?> </td>
  <td><?php  echo " ".$record[2];?> </td>
  <td><?php  echo " ".$record[3];?> </td>
  <td><?php  echo " ".$record[4];?> </td>
  
  
</tr>
  
<?php
  }

?>



</table>





            <br><br><br><br><br>
               </div>
      
         
  

</div>
</div>
    
</body>
</html>