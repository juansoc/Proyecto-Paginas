﻿<!DOCTYPE html>
<html lang="es">

<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css"> 

    <title>Pantalla De Acceso</title>
</head>
<body>
	
<a href="Pantalla1.php" class="btn btn-default btn-lg " role="button">Salir</a>

<div class="container-fluid">   
    <div class="row">

    <br><br><br><br><br>
     <div class="col-md-3 "><br><br><br></div>
<div class="col-md-3" >
	
	<label class="alert alert-danger"> <strong>¡Error!</strong> Acceso Denegado.</label>

</div>
</div>
</div>
</body>
</html>