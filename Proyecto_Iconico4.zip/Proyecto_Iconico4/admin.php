<?php 
session_start();
?>



<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<title>Administrador</title>
</head>

<?php

 

  $conexion = mysql_connect('localhost','root');
  mysql_select_db("proyecto_paginas",$conexion);

 
  
?>
 <label> <?php echo "Usuario Conectado: ".$_SESSION['UsuarioC'];?> </label>
 <br><br><br><br><br>



<body>

<div lass="container-fluid">
<div class="row">

 	<div class="col-md-4"></div>
	<div class="col-md-6">
		 <a href="proyecto.php" class="btn btn-primary btn-lg active" role="button">Crear Proyectos</a>
		 <br><br><br>
		 <a href="Consultar.php" class="btn btn-primary btn-lg active" role="button">Consultar Proyectos</a>
		 <br><br><br>
		 <a href="Imagen.php" class="btn btn-primary btn-lg active" role="button">Cargar Imagenes</a>
		 <br><br><br>
	</div>

</div>
</div>
	
</body>
</html>