<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<title>Iconico4</title>
</head>


<?php


$conexion = mysql_connect('localhost','root');
mysql_select_db("proyecto_paginas",$conexion);


$query=mysql_query("select * from proyecto");


	
?>



<body  background="Imagenes/fondo1.jpg">


<div class="container-fluid">
<div row>

<nav class="navbar navbar-inverse" role="navigation">
				  
				  	<div class="navbar-header">
						<button type="button" class="navbar-toggle"  data-toggle="collapse" 
						data-target=".navbar-ex1-collapse">
						<span class="sr-only">cambiar</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							</button><a href="index.php" class="navbar-brand">Inicio</a>
					</div>

			
      <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav">
          <li ><a href="ServiciosD.html">Servicios</a>
          </li>
        </ul>  
      

        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <li><a href="Productos.html">Productos</a>
            </li>
          </ul>  
        

        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <li><a href="Mobiliarios.html">Mobiliario</a>
            </li>
          </ul>  



        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <li ><a href="Contactenos.html">Contactenos</a>
            </li>
          </ul>  


        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <li><a href="login.php"><span class="glyphicon glyphicon-user"></span>Admin</a>
            </li>
          </ul>


        </div>
    
          </div>
        </div>
      </div>
        
				</div>

			</div>
				
				
		
		
				</nav>
<img src="Imagenes/I43.jpg" width="100%" height="150px">

<br><br>

<div class="col-md-4">
	<label>Ver Proyectos actuales</label>

	    <table class="table table-hover" background="Imagenes/fondo8.jpg">
          	<thead >
	       		<th class="success">No</th>
	       		<th class="success">Nombre de Proyecto</th>
			</thead>

			<?php
			while ($record=mysql_fetch_row($query)) {
			?>	   
			<tr>          
				<td><strong><a href="verimagenes2.php?var1=<?php  echo $record[0];?>"><?php  echo " ".$record[0];?></a></strong></td>  
				<td><strong><?php  echo " ".$record[1];?> </strong></td>
			</tr>
			<?php
			}
			?>
		</table>




</div>



<div class="col-md-4"></div>
<div class="col-md-8">
	<div class="carousel slide" id="home-carousel">
	<ol class="carousel-indicators">
		<li data-target="#home-carousel" data-slide-to="0" class="active"></li>
		<li data-target="#home-carousel" data-slide-to="1"></li>
		<li data-target="#home-carousel" data-slide-to="2"></li>
		<li data-target="#home-carousel" data-slide-to="3"></li>
		<li data-target="#home-carousel" data-slide-to="4"></li>	
	</ol>
		<div class="carousel-inner">
			<div class="item active	">
				<img src="Imagenes/slider1.jpg" alt="slider1">
			</div>
			<div class="item">
				<img src="Imagenes/slider2.jpg" alt="slider2">
			</div>
			<div class="item">
				<img src="Imagenes/slider3.jpg" alt="slider3">
			</div>
			<div class="item">
				<img src="Imagenes/slider4.jpg" alt="slider4">
			</div>
			<div class="item">
				<img src="Imagenes/slider5.jpg" alt="slider5">
			</div>
		</div>
		<a class="carousel-control left" href="#home-carousel" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
		<a class="carousel-control right" href="#home-carousel" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
			<!--<a class="carousel-control left" href="#home-carousel" data-slide="prev">&lsaquo;</a>
			<a class="carousel-control right" href="#home-carousel" data-slide="next">&rsaquo;</a> -->
	</div>
</div>
</div>
</div>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
$(document).ready(function()
{
$('.carousel').carousel();
});

</script>
</body>
</html>