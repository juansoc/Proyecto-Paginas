$(document).on('ready',botoniniciar);
function botoniniciar()  // se declara la funcion del boton iniciar
{
	$('#btnAccesar').on('click',clickbtn);
}



function clickbtn()// funcion para verificar el formulario y desplegar mensajes de error
{
	
var CNombre = document.getElementById("idNombre").value;
var CPassword = document.getElementById("idPassword").value;
var Mensaje = $('#Mensaje');
var Mensaje1 = $('#Mensaje1');


if( CNombre == null&&CPassword == null || CNombre.length == 0&&CPassword.length == 0 || /^\s+$/.test(CNombre)&&/^\s+$/.test(CPassword) ) {
    document.getElementById("Mensaje").innerHTML = "Campo Requerido";
    Mensaje.css({"color":"red"});  
    return false;
    document.getElementById("Mensaje1").innerHTML = "Campo Requerido";
    Mensaje1.css({"color":"red"});
    return false;
    }


else if( CNombre == null || CNombre.length == 0 || /^\s+$/.test(CNombre) ) {
  
    document.getElementById("Mensaje").innerHTML = "Campo Requerido";
    Mensaje.css({"color":"red"});
    return false;
    }

    else if( CPassword == null || CPassword.length == 0 || /^\s+$/.test(CPassword) ) {
  
    document.getElementById("Mensaje1").innerHTML = "Campo Requerido";
    Mensaje1.css({"color":"red"});
    return false;
    }




    else {
    	alert("Por favor confirme para acceder a la pagina");
    	//return false;
    }



}

