<!DOCTYPE html>
<html lang="es">

<head>
    
    <meta charset="UTF-8">

    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/usuario.js"></script> 

    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">


    <title>Iniciar</title>
</head>
<?php


  $conexion = mysql_connect('localhost','root');

  mysql_select_db("proyecto_paginas",$conexion);



?>
<body background="Imagenes/fondo1.jpg">


<div lass="container-fluid" id="sesion">
<div class="row">

<div class="col-md-4"></div>
<div class="col-md-4">


<form class="form-horizontal" method="POST" role="form" action="validarUsuario.php">
 
<br><br><br><br><br><br><br>

      <div class="form-group">
        <div class="col-md-1"></div>
        <div class="col-md-12">
        <label for="txtNombre" style="text-align:left;">Usuario</label>   
        <input type="text" class="form-control" id="idNombre" name="txtNombre" placeholder="Introduce tu Usuario">
        <h5 id="Mensaje"></h5>
        </div>
      </div>
        

        <br>

      <div class="form-group"> 
        <div class="col-md-1"></div>
        <div class="col-md-12">
        <label for="txtPassword" style="text-align:left;">Password</label>
        <input type="password" class="form-control" id="idPassword" name="txtPassword" placeholder="Introduce tu contraseña">
        <h5 id="Mensaje1"></h5>
        </div>      
      </div>
        
        <br>

      <div class="form-group">
        <div class="col-md-4"></div>
        <div class="col-md-4">
        <input type="submit" id="btnAccesar" value="Accesar" class="btn btn-default">
        </div>
      </div>


</form>

</div>

</div>
</div>

</body>
</html>