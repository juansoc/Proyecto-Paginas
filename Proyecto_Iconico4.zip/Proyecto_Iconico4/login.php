<!DOCTYPE html>
<html lang="es">

<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css"> 

    <title>Iniciar</title>
</head>
<?php


  $conexion = mysql_connect('localhost','root');

  mysql_select_db("proyecto_paginas",$conexion);



?>
<body>
<br>

<div lass="container-fluid">
<div class="row"> 
<form class="form-horizontal" method="POST" role="form" action="validarUsuario.php">
 <div class="form-group">
 <br><br><br><br><br><br>
<div class="col-md-3"><br><br><br><br><br><br><br></div>
 
     <label for="txtNombre" class="col-lg-1 control-label" style="text-align:left;">Usuario</label>
       <div class="col-lg-3">
        <input type="text" class="form-control" id="Nombre" name="txtNombre" placeholder="Introduce tu Usuario">
        </div>
        <br/><br/>
        <label for="txtPassword" class="col-lg-1 control-label" style="text-align:left;">Password</label>
       <div class="col-lg-3">
        <input type="password" class="form-control" id="Password" name="txtPassword" placeholder="Introduce tu contraseña">
        </div>
        <br/><br/><br/><br/>
        <div class="col-md-1"></div>
        <input type="submit" id="btnAccesar" value="Accesar" class="btn btn-default">



</div>


</form>



</div>
</div>

</body>
</html>