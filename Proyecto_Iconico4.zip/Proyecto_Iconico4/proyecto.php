<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css"> 

    <title>Crear Proyecto</title>
</head>
<?php


  $conexion = mysql_connect('localhost','root');
  mysql_select_db("proyecto_paginas",$conexion);


  $query = "SELECT * FROM tipo_proyecto";
  $quer = "SELECT * FROM usuario";

  $dato = mysql_query($query);
  $valor = mysql_query($quer);
  
?>

 <label> <?php echo "Usuario Conectado: ".$_SESSION['UsuarioC'];?> </label>

<body>
    <div class="container-fluid">
     <div class="row">  
     <br><br><br><br><br>
 

    <div class="col-lg-1"></div>  
      <div class="col-lg-3">
        <ul class="nav nav-pills nav-stacked" role="navegation" >
        <li class="active"><a href="proyecto.php" title="CrearProyecto">Crear Proyectos</a></li>
        <li ><a href="Consultar.php" class="navbar-link" title ="ConsultarProyecto">Consultar Proyectos</a></li>
        <li ><a href="Imagen.php">Cargar Imagenes</a></li>
        </ul>
    </div>
  
  
     <div class="col-md-6" style="border: 1px solid rgb(0, 0, 0);"> 
      <div class="col-md-12" style="border: 1px solid rgb(255, 255, 255);" align="center"><h2>Formulario para crear Proyectos</h2></div>
            
            <br><br><br><br>

     <form class="form-horizontal" method="POST" role="form" action="ConexionBd.php">

     <div class="form-group">
     <label for="txtNombre" class="col-lg-3 control-label" style="text-align:left;">Nombre</label>
       <div class="col-lg-9">
        <input type="text" class="form-control" id="Nombre" name="txtNombre" placeholder="Introduce tu Nombre">
        </div>
        <br/><br/>

       <label for="txtLugar"class="col-lg-3 control-label" style="text-align:left;">Lugar</label>
       <div class="col-lg-9">
        <input type="text" class="form-control" id="Lugar" name="txtLugar" placeholder="Introduce tu Lugar">
        </div>
        <br/><br/>
        
      <label for="txtFecha"class="col-lg-3 control-label" style="text-align:left;">Fecha</label>
       <div class="col-lg-9">
        <input type="text" class="form-control" id="Fecha" name="txtFecha" placeholder="Introduce Fecha">        
        </div>
        <br/><br/>

       <label for="txtObjetivo"class="col-lg-3 control-label" style="text-align:left;">Objetivo</label>
       <div class="col-lg-9">
        <input type="text" class="form-control" id="Objetivo" name="txtObjetivo" placeholder="Introduce Objetivo">        
        </div>
        <br/><br/>
        

      <label for="txtDuracion"class="col-lg-3 control-label" style="text-align:left;">Duracion</label>
       <div class="col-lg-9">
        <input type="text" class="form-control" id="Duracion" name="txtDuracion" placeholder="Introduce Duracion">        
        </div>
        <br/><br/>


        <div class="col-lg-3">
        <div class="col-lg-9"></div>
        <label style="text-align:left;">Tipo de Proyecto</label>       
        <select name="tipoProyecto">
            <?php
            while ($record=mysql_fetch_row($dato)) { 
            ?>                               
            <option value="<?php  echo " ".$record[0];?>"><?php  echo " ".$record[1];?></option>
            <?php
            }
            ?>
        </select>
        </div>
        <br/><br/>


        <div class="col-lg-3">
        <div class="col-lg-12"></div>
        <label style="text-align:left;">Usuario</label>
        <select name="usuario">
            <?php
            while ($record=mysql_fetch_row($valor)) { 
            ?>   
            <option value="<?php  echo " ".$record[0];?>"><?php  echo " ".$record[1];?></option>
            <?php
            }
            ?>
        </select>
        </div>
        <br/><br/>


<div class="col-lg-6">
<div class="col-lg-8"></div>
<input type="submit" id="btnGuardar" value="Guardar" class="btn btn-default">
</div>   
   
    </form>


</div>
</div>
</div>

</body>
</html>