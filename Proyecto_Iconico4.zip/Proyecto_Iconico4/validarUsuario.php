<?php 
session_start(); 
$_SESSION['UsuarioC']=$_REQUEST['txtNombre'];




   

    $vUsuario = $_POST['txtNombre'];
	$vContrasena =$_POST["txtPassword"];

	
	$conexion = mysql_connect('mysql4.000webhost.com','a7340928_iconico','iconico4');
	mysql_select_db("a7340928_iconico",$conexion);


	$query = "select * from usuario";
    $dato = mysql_query($query);



	while ($record=mysql_fetch_row($dato)) { 
	  
	  if ($record[3]==$vUsuario && $record[5]==$vContrasena) {
	   	echo "Usuario Correcto";
	   	header('location: proyecto.php');
	   	       break;
	         } 
		
        }


          if ($record[3]!=$vUsuario && $record[5]!=$vContrasena) {
			header('location: PantallaAcceso.php');

      	}

		

?>