<?php 
session_start(); 
$_SESSION['UsuarioC']=$_REQUEST['txtNombre'];




   

    $vUsuario = $_POST['txtNombre'];
	$vContrasena =$_POST["txtPassword"];

	
	$conexion = mysql_connect('localhost','root');
    mysql_select_db("proyecto_paginas",$conexion);

	$query = "select * from usuario";
    $dato = mysql_query($query);



	while ($record=mysql_fetch_row($dato)) { 
	  
	  if ($record[3]==$vUsuario && $record[5]==$vContrasena) {
	   	echo "Usuario Correcto";
	   	header('location: proyecto.php');
	   	       break;
	         } 
		
        }


          if ($record[3]!=$vUsuario && $record[5]!=$vContrasena) {
			header('location: PantallaAcceso.php');

      	}

		

?>