



<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<title>Proyectos Actuales</title>
</head>


<?php

$var=$_GET['var1'];

$conexion = mysql_connect('localhost','root');
mysql_select_db("proyecto_paginas",$conexion);






$query=mysql_query("select * from imagenes where proyecto_id=$var");


$dato=mysql_query("select * from proyecto where id=$var");



?>



<body  background="Imagenes/fondo8.jpg">



<div class="container-fluid">
<div row>


<br><br><br><br>

<div class="col-md-1"></div>	
<div class="col-md-4">

<form>
	<table border="1">

	

	<?php
	while ($record=mysql_fetch_array($dato)) 
	{
    ?>
	<tr>		
		<td>Nombre del Proyecto</td>
		<td><?php  echo "".$record[1];?></td>
	</tr>
	<tr>	
		<td>Fecha</td>
		<td><?php  echo "".$record[3];?></td>
	</tr>
	<tr>
		<td>Lugar de Proyecto</td>
		<td><?php  echo "".$record[2];?></td>
	</tr>
	<tr>
		<td>Objetivo</td>
		<td><?php  echo "".$record[4];?></td>
	</tr>
	<?php
	}
	?>
	<tr rowspan="15"><img src="Imagenes/Iconico4_blanco.png" width="75%" height="250px"></tr>
	</table>
</form>
</div>






<div class="col-md-7"></div>	
<div class="col-md-4">

	<table border="1">
			<?php
			while ($record=mysql_fetch_array($query)) 
			{
			?>
			<tr>
				<td><img src="<?php  echo " ".$record[3];?>" width="500px" height="300px"></td>
			</tr>
			<tr>
				<td><?php  echo " ".$record[2];?></td>				
			</tr>
			<?php
			}
			?>
	</table>
			
</div>
</div>
</div>




</body>
</html>